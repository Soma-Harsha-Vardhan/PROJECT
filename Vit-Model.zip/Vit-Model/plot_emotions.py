import matplotlib.pyplot as plt
from pymongo import MongoClient
import pandas as pd

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["emotion_db"]
collection = db["emotion_predictions"]

# Fetch records
records = list(collection.find({}))
if not records:
    print("⚠️ No data found in DB.")
    exit()

# Convert to DataFrame
df = pd.DataFrame(records)
df["timestamp"] = pd.to_datetime(df["timestamp"])

# Line plot: Confidence over time
plt.figure(figsize=(10, 5))
for emotion in df["emotion"].unique():
    subset = df[df["emotion"] == emotion]
    plt.plot(subset["timestamp"], subset["confidence"], marker='o', label=emotion)

plt.xlabel("Timestamp")
plt.ylabel("Confidence")
plt.title("Emotion Confidence Over Time")
plt.legend()
plt.grid(True)
plt.savefig("emotion_trend_db.png")
print("📈 Saved emotion_trend_db.png")
plt.show()

# Pie chart: Emotion distribution
emotion_counts = df["emotion"].value_counts()
plt.figure(figsize=(6, 6))
plt.pie(emotion_counts, labels=emotion_counts.index, autopct='%1.1f%%', startangle=140)
plt.title("Overall Emotion Distribution")
plt.savefig("emotion_distribution_db.png")
print("🥧 Saved emotion_distribution_db.png")
plt.show()
