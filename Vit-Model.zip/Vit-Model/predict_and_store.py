import cv2
import torch
import numpy as np
from torchvision import transforms
from model import VisionTransformerWithLandmarks, CLASS_NAMES, IMG_SIZE, device
from pymongo import MongoClient
import time
from collections import Counter
import mediapipe as mp

# Initialize MediaPipe Face Mesh + Drawing utils
mp_face_mesh = mp.solutions.face_mesh
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1)

# Define transforms
def get_test_transforms():
    return transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
    ])

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["emotion_db"]
collection = db["emotion_predictions"]

# Load model
model = VisionTransformerWithLandmarks().to(device)
model.load_state_dict(torch.load("best_model_5class.pth", map_location=device))
model.eval()

transform = get_test_transforms()
cap = cv2.VideoCapture(0)

emotion_counter = Counter()
last_store_time = time.time()

print("📸 Starting emotion detection with face mesh...")

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("❌ Failed to grab frame")
            break

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = face_mesh.process(rgb_frame)

        # Default landmark array if no face detected
        landmarks_np = np.zeros((468, 2), dtype=np.float32)

        if results.multi_face_landmarks:
            face_landmarks = results.multi_face_landmarks[0]
            h, w, _ = rgb_frame.shape
            landmarks_np = np.array([[lm.x * w, lm.y * h] for lm in face_landmarks.landmark], dtype=np.float32)

            # Draw face mesh
            mp_drawing.draw_landmarks(
                image=frame,
                landmark_list=face_landmarks,
                connections=mp_face_mesh.FACEMESH_TESSELATION,
                landmark_drawing_spec=None,
                connection_drawing_spec=mp_drawing_styles
                    .get_default_face_mesh_tesselation_style()
            )

            # Draw bounding box
            x_coords = landmarks_np[:, 0]
            y_coords = landmarks_np[:, 1]
            x_min = int(np.min(x_coords))
            y_min = int(np.min(y_coords))
            x_max = int(np.max(x_coords))
            y_max = int(np.max(y_coords))
            cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), (0, 255, 255), 2)

        # Normalize landmarks
        landmarks_norm = landmarks_np.flatten() / max(frame.shape[0], frame.shape[1])
        landmarks_tensor = torch.tensor(landmarks_norm, dtype=torch.float32).unsqueeze(0).to(device)

        transformed = transform(rgb_frame).unsqueeze(0).to(device)

        with torch.no_grad():
            output = model(transformed, landmarks_tensor)
            probs = torch.softmax(output, dim=1)[0].cpu().numpy()
            pred_idx = np.argmax(probs)
            pred_label = CLASS_NAMES[pred_idx]
            confidence = probs[pred_idx]

        emotion_counter[pred_label] += 1

        cv2.putText(frame, f"{pred_label} ({confidence:.2f})", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        cv2.imshow("Emotion Detection", frame)

        current_time = time.time()
        if current_time - last_store_time >= 10:
            data = {
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "emotion": pred_label,
                "confidence": float(confidence),
                "probs": {CLASS_NAMES[i]: float(probs[i]) for i in range(len(CLASS_NAMES))}
            }
            collection.insert_one(data)
            print(f"✅ Stored to DB: {data}")
            last_store_time = current_time

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    cap.release()
    cv2.destroyAllWindows()
    face_mesh.close()
    print("👋 Webcam and resources released.")
